package com.capstone.jewelrytracker;

import com.capstone.jewelrytracker.model.JewelryItem;
import com.capstone.jewelrytracker.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ProductRepositoryTest {

    @Autowired
    private ProductRepository productRepository;

    @Test
    void testAddItem() {
        JewelryItem item = new JewelryItem("Ring", "Accessory", 100.0, 5, "Gold");
        productRepository.save(item);

        assertThat(productRepository.findAll()).isNotEmpty();
    }
}