package com.capstone.jewelrytracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JewelrytrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
