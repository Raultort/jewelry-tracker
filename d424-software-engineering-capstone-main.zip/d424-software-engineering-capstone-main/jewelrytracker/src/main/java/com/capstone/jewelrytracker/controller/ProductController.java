package com.capstone.jewelrytracker.controller;

import com.capstone.jewelrytracker.model.JewelryItem;
import com.capstone.jewelrytracker.repository.ProductRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;

import java.util.List;

@Controller
public class ProductController {

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @GetMapping("/")
    public String viewHomePage(Model model) {
        List<JewelryItem> items = productRepository.findAll();
        model.addAttribute("items", items);
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("item", new JewelryItem());
        return "add-item";
    }

    @PostMapping("/save")
    public String saveItem(@Valid @ModelAttribute JewelryItem item, BindingResult result) {
        if (result.hasErrors()) {
            return "add-item";
        }
        productRepository.save(item);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteItem(@PathVariable Long id) {
        productRepository.deleteById(id);
        return "redirect:/";
    }

    @GetMapping("/search")
    public String search(@RequestParam String keyword, Model model) {
        List<JewelryItem> results = productRepository.findByNameContainingIgnoreCase(keyword);
        model.addAttribute("items", results);
        return "index";
    }

    @GetMapping("/report")
    public String generateReport(Model model) {
        List<JewelryItem> items = productRepository.findAll();
        model.addAttribute("items", items);
        model.addAttribute("reportTime", java.time.LocalDateTime.now());
        return "report";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        JewelryItem item = productRepository.findById(id).orElseThrow();
        model.addAttribute("item", item);
        return "edit-item";
    }

    @PostMapping("/update")
    public String updateItem(@ModelAttribute JewelryItem item) {
        productRepository.save(item);
        return "redirect:/";
    }
}