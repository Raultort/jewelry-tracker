package com.capstone.jewelrytracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "products")
public abstract class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Item name is required.")
    @Column(nullable = false)
    private String name;

    @NotBlank(message = "Category is required.")
    @Column(nullable = false)
    private String category;

    @NotNull(message = "Price is required.")
    @Min(value = 0, message = "Price must be zero or greater.")
    @Column(nullable = false)
    private Double price;

    @NotNull(message = "Quantity is required.")
    @Min(value = 0, message = "Quantity must be zero or greater.")
    @Column(nullable = false)
    private Integer quantity;

    public Product() {
    }

    public Product(String name, String category, Double price, Integer quantity) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
    }

    public String getProductType() {
        return "Generic Product";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}