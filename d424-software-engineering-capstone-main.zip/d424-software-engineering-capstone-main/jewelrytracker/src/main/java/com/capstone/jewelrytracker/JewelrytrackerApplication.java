package com.capstone.jewelrytracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JewelrytrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JewelrytrackerApplication.class, args);
	}

}
