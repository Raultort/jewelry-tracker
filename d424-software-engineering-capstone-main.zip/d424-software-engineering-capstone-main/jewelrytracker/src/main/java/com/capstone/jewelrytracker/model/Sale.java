package com.capstone.jewelrytracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

@Entity
@Table(name = "sales")
public class Sale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Product is required.")
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private JewelryItem product;

    @NotNull(message = "Sale quantity is required.")
    @Min(value = 1, message = "Sale quantity must be at least 1.")
    @Column(nullable = false)
    private Integer saleQuantity;

    @NotNull(message = "Sale price is required.")
    @Min(value = 0, message = "Sale price must be zero or greater.")
    @Column(nullable = false)
    private Double salePrice;

    @Column(nullable = false)
    private LocalDateTime saleDateTime;

    public Sale() {
        this.saleDateTime = LocalDateTime.now();
    }

    public Sale(JewelryItem product, Integer saleQuantity, Double salePrice) {
        this.product = product;
        this.saleQuantity = saleQuantity;
        this.salePrice = salePrice;
        this.saleDateTime = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public JewelryItem getProduct() {
        return product;
    }

    public void setProduct(JewelryItem product) {
        this.product = product;
    }

    public Integer getSaleQuantity() {
        return saleQuantity;
    }

    public void setSaleQuantity(Integer saleQuantity) {
        this.saleQuantity = saleQuantity;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public LocalDateTime getSaleDateTime() {
        return saleDateTime;
    }

    public void setSaleDateTime(LocalDateTime saleDateTime) {
        this.saleDateTime = saleDateTime;
    }
}