package com.capstone.jewelrytracker.repository;

import com.capstone.jewelrytracker.model.Sale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleRepository extends JpaRepository<Sale, Long> {
}